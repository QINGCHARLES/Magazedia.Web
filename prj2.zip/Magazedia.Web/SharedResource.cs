﻿namespace Magazedia.Web;
public class SharedResource
{
}
