using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Magazedia.Web.Pages
{
    public class DmcaModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
