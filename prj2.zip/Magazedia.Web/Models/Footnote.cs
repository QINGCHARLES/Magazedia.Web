﻿namespace WikiWikiWorld.Models
{
	public class Footnote
	{
		public string Text { get; set; }

		public Footnote(string Text)
		{
			this.Text = Text;
		}
	}
}
