﻿using Markdig.Syntax.Inlines;

namespace WikiWikiWorld.MarkdigExtensions;
public class Footnotes : LeafInline {}
