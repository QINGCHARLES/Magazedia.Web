﻿// Copyright (c) 2017 Cyotek Ltd.
// http://www.cyotek.com/blog/writing-custom-markdig-extensions
// Licensed under the MIT License. See LICENSE.txt for the full text.

using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("MarkdigMantisLink (Tests)")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Cyotek Ltd")]
[assembly: AssemblyProduct("MarkdigMantisLink")]
[assembly: AssemblyCopyright("Copyright © 2017 Cyotek Ltd. All Rights Reserved.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
//[assembly: CLSCompliant(true)]
[assembly: Guid("63e731c9-96b2-4ad8-a3bd-105474a3fc33")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
