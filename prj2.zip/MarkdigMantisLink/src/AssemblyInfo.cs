﻿// Copyright (c) 2017 Cyotek Ltd.
// http://www.cyotek.com/blog/writing-custom-markdig-extensions
// Licensed under the MIT License. See LICENSE.txt for the full text.

using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("MarkdigMantisLink")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Cyotek Ltd")]
[assembly: AssemblyProduct("MarkdigMantisLink")]
[assembly: AssemblyCopyright("Copyright © 2017 Cyotek Ltd. All Rights Reserved.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
//[assembly: CLSCompliant(true)]
[assembly: Guid("ceb3df20-f399-4de5-bc8c-738101986694")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0")]
